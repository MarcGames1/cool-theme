import './components/slider.js'

let x = 0
console.log(x)